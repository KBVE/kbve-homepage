console.log("App Starting");
rS('bootstrap_js', '3.3.7', 'https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/js/bootstrap.min.js', function(){
    rS('bootstrap_css', '3.3.7', 'https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css', function(){
        
    });
});